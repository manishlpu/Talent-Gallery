<html>
<footer>
	<h6 class="p-3 bg-dark text-white text-center ">Talley Gallery &copy; Copyright 2020 @udaichauhan Production</h6>
	</footer>
	</html>
